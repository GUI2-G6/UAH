(function(){"use strict";function U(e){return typeof e=="string"?e:typeof e=="number"||typeof e=="boolean"?String(e):""}function h(e){return U(e).toLowerCase().replace(/\s+/g," ").replace(/[^a-z0-9 ]/g,"").trim()}const M={first_name:"personal_info.first_name",last_name:"personal_info.last_name",email:"personal_info.email",phone:"personal_info.phone",address:"personal_info.address",street_address:"personal_info.address",city:"personal_info.city",state:"personal_info.state",zip:"personal_info.zip",zipcode:"personal_info.zip",postal_code:"personal_info.zip",linkedin:"personal_info.linkedin",website:"personal_info.website",portfolio:"personal_info.website",summary:"summary",work_auth:"work_auth",work_authorization:"work_auth",authorized_to_work:"work_auth",requires_sponsorship:"requires_sponsorship",sponsorship_required:"requires_sponsorship",years_experience:"years_experience",experience_years:"years_experience",professional_links:"professional_links_text",professional_links_text:"professional_links_text",additional_links:"professional_links_text"},j={education:{school:"institution",institution:"institution",university:"institution",college:"institution",degree:"degree",degree_type:"degree",field_of_study:"field_of_study",field:"field_of_study",major:"field_of_study",concentration:"field_of_study",gpa:"gpa",start_date:"start_date",start_month:"start_month",start_year:"start_year",end_date:"end_date",end_month:"end_month",end_year:"end_year",currently_enrolled:"is_current",currently_attend_here:"is_current",is_current:"is_current",graduation:"end_date",honors:"honors",coursework:"relevant_coursework"},work_experience:{title:"title",job_title:"title",position:"title",role:"title",company:"company",employer:"company",organization:"company",location:"location",start_date:"start_date",start_month:"start_month",start_year:"start_year",end_date:"end_date",end_month:"end_month",end_year:"end_year",currently_work_here:"is_current",is_current:"is_current",description:"bullets",duties:"bullets",responsibilities:"bullets"},projects:{name:"name",project_name:"name",description:"description",technologies:"technologies",url:"url",date:"date"}},B=/^(\w+)\[(\d+)\]\.(\w+)$/,V=[{path:"personal_info.first_name",terms:["first name","given name","fname","legal first name","legal name first"]},{path:"personal_info.last_name",terms:["last name","surname","family name","lname","legal last name","legal name last"]},{path:"personal_info.email",terms:["email","email address","e mail","e mail address"]},{path:"personal_info.phone",terms:["phone","phone number","mobile","cell","telephone","contact number"]},{path:"personal_info.address",terms:["address","street address","address line 1","address line","mailing address"]},{path:"personal_info.city",terms:["city","city town"]},{path:"personal_info.state",terms:["state","state province","region","province"]},{path:"personal_info.zip",terms:["zip","zip code","postal code","zipcode"]},{path:"personal_info.linkedin",terms:["linkedin","linkedin url","linkedin profile"]},{path:"personal_info.website",terms:["website","portfolio","personal website","homepage","web page"]},{path:"education[0].institution",terms:["school","university","institution","college","school name","university name"]},{path:"education[0].degree",terms:["degree","degree type","level of education"]},{path:"education[0].field_of_study",terms:["field of study","major","concentration","area of study","program"]},{path:"education[0].gpa",terms:["gpa","grade point average","grade point","cumulative gpa"]},{path:"education[0].start_date",terms:["education start","edu start date","from date education"]},{path:"education[0].end_date",terms:["education end","edu end date","graduation date","expected graduation","completion date"]},{path:"education[0].is_current",terms:["i currently attend here","currently enrolled","currently attending","still enrolled","current student"]},{path:"work_experience[0].company",terms:["company","employer","organization","company name","employer name"]},{path:"work_experience[0].title",terms:["job title","position","title","role","position title"]},{path:"work_experience[0].location",terms:["work location","job location","location"]},{path:"work_experience[0].start_date",terms:["work start","employment start","start date","from"]},{path:"work_experience[0].end_date",terms:["work end","employment end","end date","to"]},{path:"work_experience[0].is_current",terms:["i currently work here","currently employed","current position","currently working","present position"]},{path:"work_experience[0].bullets",terms:["description","duties","responsibilities","job description"]},{path:"summary",terms:["summary","objective","professional summary","cover letter","about"]},{path:"work_auth",terms:["work auth","work authorization","authorized to work","legally authorized to work","authorization to work","eligible to work"]},{path:"requires_sponsorship",terms:["requires sponsorship","sponsorship required","need sponsorship","visa sponsorship","require sponsorship"]},{path:"years_experience",terms:["years of experience","total years of experience","experience in years","relevant experience years"]},{path:"professional_links_text",terms:["professional links","additional links","github","github profile","additional websites"]}];function G(e){return String(e||"").trim().toLowerCase().replace(/-/g,"_")}function z(e){const n=G(e);if(!n)return null;if(M[n])return M[n];const t=n.match(B);if(t){const[,r,o,a]=t,s=j[r]?.[a]||a;return`${r}[${o}].${s}`}const i=n.match(/^currently_work_here_(\d+)$/);return i?`work_experience[${i[1]}].is_current`:null}function Y(e,n){let t=0;for(const i of n){const r=h(i);if(r)if(e===r)t=Math.max(t,1);else if(e.includes(r))t=Math.max(t,.85);else if(r.includes(e)&&e.length>3)t=Math.max(t,.75);else{const o=new Set(e.split(" ")),a=r.split(" "),c=a.filter(s=>o.has(s)).length;c>0&&(t=Math.max(t,Math.min(.7,c/Math.max(1,a.length))))}}return t}function X(e,n){let t={path:null,score:0};for(const i of V){if(n[i.path]===void 0)continue;const r=Y(e,i.terms);r>t.score&&(t={path:i.path,score:r})}if(t.score<.5)for(const i of Object.keys(n||{})){const r=i.split(".").pop()?.replace(/\[\d+\]/g,"")||"",o=h(r.replace(/_/g," "));if(o&&e.includes(o)&&o.length>2){t={path:i,score:.55};break}}return t}function K(e,n){return(Array.isArray(e)?e:[]).map(t=>{let i=null,r=0;const o=z(t.name);if(o&&n[o]!==void 0&&(i=o,r=1),!i){const a=z(t.id);a&&n[a]!==void 0&&(i=a,r=.95)}if(!i||r<.8){const a=X(t.labelNorm||"",n);a.score>r&&(i=a.path,r=a.score)}return{...t,matchPath:i,matchScore:r}})}const v=globalThis.Event||class{constructor(n,t={}){this.type=n,this.bubbles=!!t.bubbles}};function Q({required:e=!1,ariaRequired:n=!1,label:t=""}={}){return e||n?!0:String(t||"").includes("*")}function R(e,n=document){if(!e)return"";if(e.id){const c=globalThis.CSS?.escape?globalThis.CSS.escape(e.id):e.id.replace(/"/g,'\\"'),s=n.querySelector(`label[for="${c}"]`);if(s?.textContent)return s.textContent.trim()}const t=e.closest?.("label");if(t){const c=t.cloneNode(!0);c.querySelectorAll?.("input, textarea, select")?.forEach(l=>l.remove());const s=c.textContent?.trim();if(s)return s}const i=e.getAttribute?.("aria-label");if(i)return i;const r=e.getAttribute?.("placeholder");if(r)return r;const o=e.getAttribute?.("data-label");if(o)return o;const a=e.parentElement;if(a){const c=a.querySelector?.("span:not(.error), .label, .field-label");if(c?.textContent?.trim()?.length<60)return c.textContent.trim();const s=a.innerText?.trim();if(s&&s.length<80)return s}return""}function J(e){if(!e)return!1;const n=typeof e.getBoundingClientRect=="function"?e.getBoundingClientRect():{width:0,height:0};return n.width>0||n.height>0||e.offsetParent!==null}function Z(e=document){return Array.from(e.querySelectorAll("input, textarea, select")).filter(n=>!n.disabled).filter(n=>n.type!=="hidden").filter(n=>!["submit","button","reset"].includes(n.type)).filter(n=>{const t=h(R(n,e));return!(t.includes("search")&&!t.includes("job"))}).filter(J).map(n=>{const t=R(n,e);return{el:n,label:t,labelNorm:h(t),name:n.getAttribute?.("name")||"",id:n.id||"",required:Q({required:!!n.required,ariaRequired:n.getAttribute?.("aria-required")==="true",label:t}),tagName:n.tagName?.toLowerCase?.()||"",inputType:n.type||""}})}function k(e,n=document){return K(Z(n),e||{})}function ee(e,n){try{if(!e)return!1;if(e.tagName?.toLowerCase?.()==="select"){const t=Array.from(e.options||[]),i=h(String(n));let r=t.find(o=>h(o.textContent)===i);if(r||(r=t.find(o=>h(o.value)===i)),r||(r=t.find(o=>h(o.textContent).includes(i))),r||(r=t.find(o=>{const a=h(o.textContent);return a.length>1&&i.includes(a)})),!r)return!1;e.value=r.value}else if(e.type==="checkbox"){const t=n===!0||n==="true"||n==="1";return e.checked!==t&&e.click?.(),!0}else if(e.type==="radio"){const t=h(String(n));return h(e.value)!==t?!1:(e.click?.(),!0)}else e.focus?.(),e.value=String(n);return e.dispatchEvent?.(new v("input",{bubbles:!0})),e.dispatchEvent?.(new v("change",{bubbles:!0})),e.dispatchEvent?.(new v("blur",{bubbles:!0})),!0}catch{return!1}}function te(e,n){let t=0;const i=[...Array.isArray(e)?e:[]].sort((r,o)=>{const a=r.matchPath?.endsWith(".is_current")?0:1,c=o.matchPath?.endsWith(".is_current")?0:1;return a-c});for(const r of i){if(!r.matchPath||r.matchScore<.5)continue;const o=n?.[r.matchPath];if(!(o==null||o==="")){if(r.matchPath.match(/\.(end_month|end_year|end_date)$/)){const a=r.matchPath.replace(/\.(end_month|end_year|end_date)$/,"");if(n?.[`${a}.is_current`]===!0)continue}ee(r.el,o)&&(t+=1)}}return t}function S(e){const n=Array.isArray(e)?e:[],t=n.filter(o=>o.matchPath&&o.matchScore>=.75).length,i=n.filter(o=>o.matchPath&&o.matchScore>=.5&&o.matchScore<.75).length,r=n.filter(o=>o.required&&!o.matchPath).length;return{total:n.length,matched:t+i,good:t,review:i,missing:r}}function T(e=document){e.querySelectorAll(".uah-fill-good, .uah-fill-review, .uah-fill-missing").forEach(n=>n.classList.remove("uah-fill-good","uah-fill-review","uah-fill-missing"))}function C(e){(Array.isArray(e)?e:[]).forEach(n=>{n.el&&(n.matchPath&&n.matchScore>=.75?n.el.classList.add("uah-fill-good"):n.matchPath&&n.matchScore>=.5?n.el.classList.add("uah-fill-review"):n.required&&n.el.classList.add("uah-fill-missing"))})}const q=globalThis.browser,A=globalThis.chrome;function ne(){return A?.runtime?.lastError?.message||""}function re(e,n,...t){return new Promise((i,r)=>{const o=e?.[n];if(typeof o!="function"){r(new Error(`Extension API method '${n}' is unavailable.`));return}try{o.call(e,...t,a=>{const c=ne();if(c){r(new Error(c));return}i(a)})}catch(a){r(a)}})}function oe(e,n,...t){const i=e?.[n];return typeof i!="function"?Promise.reject(new Error(`Extension API method '${n}' is unavailable.`)):Promise.resolve(i.call(e,...t))}function ie(e,n,...t){return q?oe(e(q),n,...t):A?re(e(A),n,...t):Promise.reject(new Error("Browser extension APIs are unavailable in this context."))}function ae(e){return ie(n=>n.runtime,"sendMessage",e)}async function se(e,n={}){const t=await ae({type:e,payload:n});if(!t?.ok){const i=new Error(t?.message||"Extension request failed.");throw i.code=t?.code||"EXTENSION_REQUEST_FAILED",i.status=t?.status||null,i}return t.data}const L=16,I=196,le=380,x=340,ue=Object.freeze({pinEnabled:!1,themePreference:"system",panelPosition:null,panelSize:null,panelResizeUnlocked:!1,debugPosition:null});function O(e){const n=Number(e);return Number.isFinite(n)?n:null}function ce(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const n=O(e.top),t=O(e.left);return n===null||t===null?null:{top:Math.round(n),left:Math.round(t)}}function w({viewportWidth:e=1280,width:n=I,top:t=L,margin:i=L}={}){const r=Math.max(i,Math.round(e-n-i));return{top:Math.max(i,Math.round(t)),left:r}}function $(e,{viewportWidth:n=1280,viewportHeight:t=720,width:i=I,height:r=le,margin:o=L}={}){const a=ce(e)||w({viewportWidth:n,width:i,margin:o}),c=Math.max(o,Math.round(n-i-o)),s=Math.max(o,Math.round(t-r-o));return{left:Math.min(c,Math.max(o,a.left)),top:Math.min(s,Math.max(o,a.top))}}function de(e,n){!e||!n||(e.style.left=`${n.left}px`,e.style.top=`${n.top}px`)}function D(e,n,t={}){return{viewportWidth:n.innerWidth||1280,viewportHeight:n.innerHeight||720,width:e?.offsetWidth||t.width||0,height:e?.offsetHeight||t.height||0}}function fe({handle:e,target:n,initialPosition:t=null,defaultPosition:i=null,ignoreSelector:r='button, a, input, select, textarea, [role="button"]',fallbackSize:o={},onMove:a=null,onCommit:c=null,win:s=window}={}){if(!e||!n||!s?.addEventListener)return{getPosition:()=>null,setPosition(){},destroy(){}};let l=$(t||i||w(D(n,s,o)),D(n,s,o)),d=!1,g=0,E=0,f=l.left,_=l.top;function b(p,me=!0){l=$(p,D(n,s,o)),de(n,l),me&&typeof a=="function"&&a({...l})}function y(p){d&&(p.preventDefault(),b({left:f+(p.clientX-g),top:_+(p.clientY-E)}))}function m(){d&&(d=!1,s.removeEventListener("pointermove",y),s.removeEventListener("pointerup",m),typeof c=="function"&&c({...l}))}function W(p){p.button!==void 0&&p.button!==0||r&&p.target?.closest?.(r)||(d=!0,g=p.clientX,E=p.clientY,f=l.left,_=l.top,s.addEventListener("pointermove",y),s.addEventListener("pointerup",m))}return e.addEventListener("pointerdown",W),b(l,!1),{getPosition(){return{...l}},setPosition(p){b(p,!1)},destroy(){d=!1,e.removeEventListener("pointerdown",W),s.removeEventListener("pointermove",y),s.removeEventListener("pointerup",m)}}}const u="uah-profile-autofill-overlay",H="uah-profile-autofill-style";function P(e){const n=document.createElement("span");return n.textContent=String(e??""),n.innerHTML}function N(e=document){if(e.getElementById(H))return;const n=e.createElement("style");n.id=H,n.textContent=`
    #${u} {
      position: fixed;
      width: ${x}px;
      max-height: 82vh;
      overflow: auto;
      z-index: 2147483646;
      font: 13px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      color: #0f172a;
      background: rgba(255, 255, 255, 0.98);
      border: 1px solid rgba(148, 163, 184, 0.45);
      border-radius: 14px;
      box-shadow: 0 18px 48px rgba(15, 23, 42, 0.18);
    }
    #${u} .uah-autofill-header,
    #${u} .uah-autofill-body {
      padding: 12px 14px;
    }
    #${u} .uah-autofill-header {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      align-items: flex-start;
      border-bottom: 1px solid rgba(226, 232, 240, 0.9);
      background: linear-gradient(135deg, #eff6ff, #f8fafc);
      cursor: move;
      user-select: none;
    }
    #${u} .uah-autofill-kicker {
      margin: 0 0 4px;
      color: #1d4ed8;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }
    #${u} .uah-autofill-title,
    #${u} .uah-autofill-note,
    #${u} .uah-autofill-path,
    #${u} .uah-autofill-preview {
      margin: 0;
    }
    #${u} .uah-autofill-title {
      font-size: 14px;
      font-weight: 700;
    }
    #${u} .uah-autofill-actions {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-top: 10px;
    }
    #${u} .uah-autofill-btn,
    #${u} .uah-autofill-close {
      border: 1px solid rgba(191, 219, 254, 1);
      border-radius: 999px;
      background: white;
      color: #1d4ed8;
      padding: 6px 10px;
      font-size: 12px;
      font-weight: 700;
      cursor: pointer;
    }
    #${u} .uah-autofill-pills {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-bottom: 12px;
    }
    #${u} .uah-autofill-pill {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 4px 8px;
      border-radius: 999px;
      background: #eff6ff;
      color: #1d4ed8;
      font-size: 12px;
      font-weight: 700;
    }
    #${u} .uah-autofill-note {
      color: #475569;
      margin-bottom: 10px;
    }
    #${u} .uah-autofill-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    #${u} .uah-autofill-item {
      padding: 10px;
      border: 1px solid rgba(226, 232, 240, 0.95);
      border-radius: 10px;
      background: #f8fafc;
      cursor: pointer;
    }
    #${u} .uah-autofill-item:hover {
      border-color: rgba(96, 165, 250, 0.9);
      background: #eff6ff;
    }
    #${u} .uah-autofill-item-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      margin-bottom: 4px;
    }
    #${u} .uah-autofill-item-title {
      font-weight: 700;
      color: #0f172a;
    }
    #${u} .uah-autofill-item-score {
      color: #475569;
      font-size: 11px;
      white-space: nowrap;
    }
    #${u} .uah-autofill-path {
      color: #334155;
      font-size: 11px;
      word-break: break-word;
    }
    #${u} .uah-autofill-preview {
      color: #475569;
      font-size: 11px;
      margin-top: 4px;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .uah-fill-good { outline: 2px solid #16a34a !important; }
    .uah-fill-review { outline: 2px solid #d97706 !important; }
    .uah-fill-missing { outline: 2px solid #dc2626 !important; }
  `,e.head.appendChild(n)}function pe(e=document){return e.getElementById(u)}function F(e){return e&&typeof e=="object"?{...e}:{}}function he(e=window,n=document){if(e.__UAH_RESUME_TESTER__)return e.__UAH_RESUME_TESTER__;const t={currentPlan:null,currentTokens:null,notice:"",uiState:{...ue},overlayDrag:null};function i(l){t.uiState.debugPosition=l,se("setPinnedUiState",{debugPosition:l}).catch(()=>null)}function r(){const l=pe(n);t.overlayDrag&&(t.uiState.debugPosition=t.overlayDrag.getPosition(),t.overlayDrag.destroy(),t.overlayDrag=null),l?.remove()}function o(){r()}function a(){if(r(),!t.currentPlan)return;const l=S(t.currentPlan),d=n.createElement("div");d.id=u;const g=t.currentPlan.filter(f=>f.matchPath||f.required).sort((f,_)=>{const b=f.matchPath?f.matchScore:-1;return(_.matchPath?_.matchScore:-1)-b}).slice(0,30);d.innerHTML=`
      <div class="uah-autofill-header">
        <div>
          <p class="uah-autofill-kicker">UAH Autofill Debug</p>
          <p class="uah-autofill-title">Manual scan plan for this page</p>
        </div>
        <button class="uah-autofill-close" type="button" aria-label="Close">Close</button>
      </div>
      <div class="uah-autofill-body">
        <div class="uah-autofill-pills">
          <span class="uah-autofill-pill">Fields <b>${l.total}</b></span>
          <span class="uah-autofill-pill">Good <b>${l.good}</b></span>
          <span class="uah-autofill-pill">Review <b>${l.review}</b></span>
          <span class="uah-autofill-pill">Missing <b>${l.missing}</b></span>
        </div>
        <p class="uah-autofill-note">${P(t.notice||"Highlighting fields matched from the selected UAH profile.")}</p>
        <div class="uah-autofill-actions">
          <button class="uah-autofill-btn" type="button" data-action="fill">Fill matched fields</button>
          <button class="uah-autofill-btn" type="button" data-action="rescan">Re-scan page</button>
        </div>
        <div class="uah-autofill-list"></div>
      </div>
    `;const E=d.querySelector(".uah-autofill-list");g.forEach(f=>{const _=f.matchPath?`${Math.round(f.matchScore*100)}%`:"Required",b=f.label?.trim()||f.name||f.id||"(unlabeled field)",y=f.matchPath&&t.currentTokens?.[f.matchPath]!==void 0?String(t.currentTokens[f.matchPath]).slice(0,80):"",m=n.createElement("button");m.type="button",m.className="uah-autofill-item",m.innerHTML=`
        <div class="uah-autofill-item-top">
          <span class="uah-autofill-item-title">${P(b)}</span>
          <span class="uah-autofill-item-score">${P(_)}</span>
        </div>
        <p class="uah-autofill-path">${P(f.matchPath||"No token match")}</p>
        ${y?`<p class="uah-autofill-preview">${P(y)}</p>`:""}
      `,m.addEventListener("click",()=>{f.el?.scrollIntoView?.({behavior:"smooth",block:"center"}),f.el?.focus?.()}),E.appendChild(m)}),d.querySelector(".uah-autofill-close")?.addEventListener("click",o),d.querySelector('[data-action="fill"]')?.addEventListener("click",()=>{e.__UAH_RESUME_TESTER__?.fill(t.currentTokens)}),d.querySelector('[data-action="rescan"]')?.addEventListener("click",()=>{t.currentPlan=k(t.currentTokens,n),t.notice="Re-scanned the current page.",T(n),C(t.currentPlan),a()}),n.body.appendChild(d),t.overlayDrag=fe({handle:d.querySelector(".uah-autofill-header"),target:d,initialPosition:t.uiState.debugPosition,defaultPosition:w({viewportWidth:e.innerWidth,width:x}),fallbackSize:{width:x,height:d.offsetHeight||420},onCommit(f){i(f)},win:e}),t.overlayDrag.setPosition($(t.uiState.debugPosition||w({viewportWidth:e.innerWidth,width:x}),{viewportWidth:e.innerWidth,viewportHeight:e.innerHeight,width:d.offsetWidth||x,height:d.offsetHeight||420}))}function c(){T(n),t.currentPlan&&C(t.currentPlan),a()}e.addEventListener("resize",()=>{t.overlayDrag&&t.overlayDrag.setPosition(t.overlayDrag.getPosition())});const s={configure(l={}){t.uiState={...t.uiState,...l},t.overlayDrag&&t.overlayDrag.setPosition(t.uiState.debugPosition||t.overlayDrag.getPosition())},scan(l){return N(n),t.currentTokens=F(l),t.currentPlan=k(t.currentTokens,n),t.notice="Scanned visible inputs, textareas, and selects on the current page.",c(),S(t.currentPlan)},fill(l){N(n);const d=F(l);Object.keys(d).length&&(t.currentTokens=d),(!t.currentPlan||!t.currentTokens)&&(t.currentTokens=t.currentTokens||d,t.currentPlan=k(t.currentTokens,n));const g=te(t.currentPlan,t.currentTokens);return t.notice=`Filled ${g} field${g===1?"":"s"} from the active plan.`,c(),{filled:g,total:t.currentPlan.length}},remove(){return r(),n.getElementById(H)?.remove(),T(n),t.currentPlan=null,t.currentTokens=null,t.notice="",{ok:!0}},getStats(){return t.currentPlan?S(t.currentPlan):null}};return e.__UAH_RESUME_TESTER__=s,s}he()})();
