(function(){"use strict";const N=globalThis.browser,L=globalThis.chrome;function C(){return L?.runtime?.lastError?.message||""}function B(t,n,...e){return new Promise((r,h)=>{const d=t?.[n];if(typeof d!="function"){h(new Error(`Extension API method '${n}' is unavailable.`));return}try{d.call(t,...e,c=>{const g=C();if(g){h(new Error(g));return}r(c)})}catch(c){h(c)}})}function F(t,n,...e){const r=t?.[n];return typeof r!="function"?Promise.reject(new Error(`Extension API method '${n}' is unavailable.`)):Promise.resolve(r.call(t,...e))}function O(t,n,...e){return N?F(t(N),n,...e):L?B(t(L),n,...e):Promise.reject(new Error("Browser extension APIs are unavailable in this context."))}function Q(t){return O(n=>n.runtime,"sendMessage",t)}async function x(t,n={}){const e=await Q({type:t,payload:n});if(!e?.ok){const r=new Error(e?.message||"Extension request failed.");throw r.code=e?.code||"EXTENSION_REQUEST_FAILED",r.status=e?.status||null,r}return e.data}const z=16,b=196,P=380,$=196,A=320,T=720,q=Object.freeze({pinEnabled:!1,themePreference:"system",panelPosition:null,panelSize:null,panelResizeUnlocked:!1,debugPosition:null});function w(t){const n=Number(t);return Number.isFinite(n)?n:null}function X(t){if(!t||typeof t!="object"||Array.isArray(t))return null;const n=w(t.top),e=w(t.left);return n===null||e===null?null:{top:Math.round(n),left:Math.round(e)}}function j(t){if(!t||typeof t!="object"||Array.isArray(t))return null;const n=w(t.width),e=w(t.height);return n===null||e===null?null:{width:Math.round(n),height:Math.round(e)}}function y({viewportWidth:t=1280,width:n=b,top:e=z,margin:r=z}={}){const h=Math.max(r,Math.round(t-n-r));return{top:Math.max(r,Math.round(e)),left:h}}function E(t,{viewportWidth:n=1280,viewportHeight:e=720,minWidth:r=$,minHeight:h=A,maxWidth:d=T,margin:c=z}={}){const g=j(t)||{width:b,height:P},l=Math.max(r,Math.min(d,Math.round(n-c*2))),f=Math.max(h,Math.round(e-c*2));return{width:Math.min(l,Math.max(r,g.width)),height:Math.min(f,Math.max(h,g.height))}}function I(t={}){return E({width:b,height:P},t)}function S(t,{viewportWidth:n=1280,viewportHeight:e=720,width:r=b,height:h=P,margin:d=z}={}){const c=X(t)||y({viewportWidth:n,width:r,margin:d}),g=Math.max(d,Math.round(n-r-d)),l=Math.max(d,Math.round(e-h-d));return{left:Math.min(g,Math.max(d,c.left)),top:Math.min(l,Math.max(d,c.top))}}function G(t,n){!t||!n||(t.style.left=`${n.left}px`,t.style.top=`${n.top}px`)}function H(t,n,e={}){return{viewportWidth:n.innerWidth||1280,viewportHeight:n.innerHeight||720,width:t?.offsetWidth||e.width||0,height:t?.offsetHeight||e.height||0}}function Y({handle:t,target:n,initialPosition:e=null,defaultPosition:r=null,ignoreSelector:h='button, a, input, select, textarea, [role="button"]',fallbackSize:d={},onMove:c=null,onCommit:g=null,win:l=window}={}){if(!t||!n||!l?.addEventListener)return{getPosition:()=>null,setPosition(){},destroy(){}};let f=S(e||r||y(H(n,l,d)),H(n,l,d)),v=!1,M=0,k=0,_=f.left,i=f.top;function a(o,te=!0){f=S(o,H(n,l,d)),G(n,f),te&&typeof c=="function"&&c({...f})}function s(o){v&&(o.preventDefault(),a({left:_+(o.clientX-M),top:i+(o.clientY-k)}))}function p(){v&&(v=!1,l.removeEventListener("pointermove",s),l.removeEventListener("pointerup",p),typeof g=="function"&&g({...f}))}function m(o){o.button!==void 0&&o.button!==0||h&&o.target?.closest?.(h)||(v=!0,M=o.clientX,k=o.clientY,_=f.left,i=f.top,l.addEventListener("pointermove",s),l.addEventListener("pointerup",p))}return t.addEventListener("pointerdown",m),a(f,!1),{getPosition(){return{...f}},setPosition(o){a(o,!1)},destroy(){v=!1,t.removeEventListener("pointerdown",m),l.removeEventListener("pointermove",s),l.removeEventListener("pointerup",p)}}}const V=new Set(["system","light","dark"]);function U(t){const n=String(t||"").trim().toLowerCase();return V.has(n)?n:"system"}function W(t,n=globalThis.window){const e=U(t);if(e==="light")return"light";if(e==="dark")return"dark";if(!n||typeof n.matchMedia!="function")return"light";try{return n.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}catch{return"light"}}const u="uah-pinned-panel-root",R="uah-pinned-panel-style";function J(t=document){if(t.getElementById(R))return;const n=t.createElement("style");n.id=R,n.textContent=`
    #${u} {
      --panel-surface: rgba(248, 250, 252, 0.96);
      --panel-surface-muted: rgba(248, 250, 252, 0.98);
      --panel-border: rgba(191, 219, 254, 0.92);
      --panel-shadow: rgba(15, 23, 42, 0.28);
      --panel-title: #0f172a;
      --panel-kicker: #1d4ed8;
      --panel-header-bg-start: rgba(239, 246, 255, 0.98);
      --panel-header-bg-end: rgba(255, 255, 255, 0.96);
      --panel-header-border: rgba(226, 232, 240, 0.9);
      --panel-button-bg: #ffffff;
      --panel-button-text: #1d4ed8;
      --panel-button-border: rgba(191, 219, 254, 1);
      --panel-button-active-bg: #1d4ed8;
      --panel-button-active-text: #ffffff;
      position: fixed;
      z-index: 2147483645;
      width: ${b}px;
      height: min(${P}px, calc(100vh - 32px));
      min-width: ${$}px;
      min-height: ${A}px;
      max-width: min(${T}px, calc(100vw - 32px));
      max-height: calc(100vh - 32px);
      border-radius: 18px;
      border: 1px solid var(--panel-border);
      box-shadow: 0 24px 64px var(--panel-shadow);
      overflow: hidden;
      background: var(--panel-surface);
      backdrop-filter: blur(16px);
      resize: none;
    }
    #${u}[data-theme="dark"] {
      --panel-surface: rgba(15, 23, 42, 0.96);
      --panel-surface-muted: rgba(30, 41, 59, 0.98);
      --panel-border: rgba(71, 85, 105, 0.78);
      --panel-shadow: rgba(2, 6, 23, 0.62);
      --panel-title: #f1f5f9;
      --panel-kicker: #7cb6ff;
      --panel-header-bg-start: rgba(15, 23, 42, 0.96);
      --panel-header-bg-end: rgba(30, 41, 59, 0.96);
      --panel-header-border: rgba(71, 85, 105, 0.72);
      --panel-button-bg: rgba(15, 23, 42, 0.92);
      --panel-button-text: #cfe3ff;
      --panel-button-border: rgba(100, 116, 139, 0.72);
      --panel-button-active-bg: #7cb6ff;
      --panel-button-active-text: #0f172a;
    }
    #${u}::after {
      content: "";
      position: absolute;
      right: 0;
      bottom: 0;
      width: 18px;
      height: 18px;
      background: var(--panel-surface-muted);
      pointer-events: none;
    }
    #${u}.uah-pinned-panel--resize-unlocked {
      resize: both;
    }
    #${u}.uah-pinned-panel--resize-unlocked::after {
      display: none;
    }
    #${u} .uah-pinned-panel__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px 14px;
      background: linear-gradient(135deg, var(--panel-header-bg-start), var(--panel-header-bg-end));
      border-bottom: 1px solid var(--panel-header-border);
      cursor: move;
      user-select: none;
    }
    #${u} .uah-pinned-panel__eyebrow {
      margin: 0 0 4px;
      color: var(--panel-kicker);
      font: 700 11px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }
    #${u} .uah-pinned-panel__title {
      margin: 0;
      color: var(--panel-title);
      font: 700 15px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    #${u} .uah-pinned-panel__actions {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-shrink: 0;
    }
    #${u} .uah-pinned-panel__button {
      border: 1px solid var(--panel-button-border);
      border-radius: 999px;
      background: var(--panel-button-bg);
      color: var(--panel-button-text);
      padding: 7px 11px;
      font: 700 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      cursor: pointer;
    }
    #${u} .uah-pinned-panel__button--active {
      background: var(--panel-button-active-bg);
      border-color: var(--panel-button-active-bg);
      color: var(--panel-button-active-text);
    }
    #${u} iframe {
      display: block;
      width: 100%;
      height: calc(100% - 60px);
      border: 0;
      background: transparent;
    }
    #${u}.uah-pinned-panel--compact {
      border-radius: 16px;
    }
    #${u}.uah-pinned-panel--compact .uah-pinned-panel__header {
      flex-wrap: wrap;
      align-items: flex-start;
    }
    #${u}.uah-pinned-panel--compact .uah-pinned-panel__actions {
      width: 100%;
      justify-content: flex-end;
    }
  `,t.head.appendChild(n)}function D(t=document){return t.getElementById(u)}function K(t=document){D(t)?.remove()}function Z(){return`${globalThis.chrome?.runtime?.getURL?.("popup.html")||""}?surface=pinned`}function ee(t=window,n=document){if(t.__UAH_PINNED_PANEL__)return t.__UAH_PINNED_PANEL__;const e={uiState:{...q},themeMediaQuery:null,handleThemeMediaChange:null,drag:null,resizeHandler:null,panelResizeObserver:null};function r(){e.drag?.destroy?.(),e.drag=null}function h(){!e.themeMediaQuery||!e.handleThemeMediaChange||(typeof e.themeMediaQuery.removeEventListener=="function"?e.themeMediaQuery.removeEventListener("change",e.handleThemeMediaChange):typeof e.themeMediaQuery.removeListener=="function"&&e.themeMediaQuery.removeListener(e.handleThemeMediaChange),e.themeMediaQuery=null,e.handleThemeMediaChange=null)}function d(i){if(!i)return;const a=U(e.uiState.themePreference),s=W(a,t);if(i.dataset.theme=s,h(),a!=="system")return;const p=t.matchMedia?.("(prefers-color-scheme: dark)");if(!p)return;const m=()=>{i.dataset.theme=W("system",t)};typeof p.addEventListener=="function"?p.addEventListener("change",m):typeof p.addListener=="function"&&p.addListener(m),e.themeMediaQuery=p,e.handleThemeMediaChange=m}function c(){const i={viewportWidth:t.innerWidth,viewportHeight:t.innerHeight};return e.uiState.panelResizeUnlocked?E(e.uiState.panelSize,i):I(i)}function g(i){const a=!!e.uiState.panelResizeUnlocked;i.classList.toggle("uah-pinned-panel--resize-unlocked",a)}function l(i,a){const s=c();i.style.width=`${s.width}px`,i.style.height=`${s.height}px`,i.classList.toggle("uah-pinned-panel--compact",s.width<340),g(i);const p=S(a||y({viewportWidth:t.innerWidth,width:b}),{viewportWidth:t.innerWidth,viewportHeight:t.innerHeight,width:s.width,height:s.height});e.drag?.setPosition(p)}function f(i){r();const a=i.querySelector(".uah-pinned-panel__header");e.drag=Y({handle:a,target:i,initialPosition:e.uiState.panelPosition,defaultPosition:y({viewportWidth:t.innerWidth,width:b}),fallbackSize:{width:b,height:P},onCommit(s){e.uiState.panelPosition=s,x("setPinnedUiState",{panelPosition:s}).catch(()=>null)},win:t})}function v(i){e.resizeHandler||(e.resizeHandler=()=>{e.uiState.panelSize=E(e.uiState.panelSize,{viewportWidth:t.innerWidth,viewportHeight:t.innerHeight});const a=e.drag?.getPosition?.()||e.uiState.panelPosition;l(i,a)},t.addEventListener("resize",e.resizeHandler))}function M(i){e.panelResizeObserver||typeof globalThis.ResizeObserver!="function"||(e.panelResizeObserver=new ResizeObserver(()=>{const a=E({width:i.offsetWidth,height:i.offsetHeight},{viewportWidth:t.innerWidth,viewportHeight:t.innerHeight});if(i.style.width=`${a.width}px`,i.style.height=`${a.height}px`,i.classList.toggle("uah-pinned-panel--compact",a.width<340),e.uiState.panelSize?.width!==a.width||e.uiState.panelSize?.height!==a.height){e.uiState.panelSize=a;const s=e.drag?.getPosition?.()||e.uiState.panelPosition;l(i,s),x("setPinnedUiState",{panelSize:a}).catch(()=>null)}}),e.panelResizeObserver.observe(i))}function k(){let i=D(n);if(i)return i;const a=c(),s=S(e.uiState.panelPosition||y({viewportWidth:t.innerWidth,width:a.width}),{viewportWidth:t.innerWidth,viewportHeight:t.innerHeight,width:a.width,height:a.height});i=n.createElement("div"),i.id=u,i.style.width=`${a.width}px`,i.style.height=`${a.height}px`,i.style.left=`${s.left}px`,i.style.top=`${s.top}px`,i.style.display="none",i.classList.toggle("uah-pinned-panel--compact",a.width<340),d(i),i.innerHTML=`
      <div class="uah-pinned-panel__header">
        <div>
          <p class="uah-pinned-panel__eyebrow">UAH Browser Companion</p>
          <p class="uah-pinned-panel__title">Pinned applicant panel</p>
        </div>
        <div class="uah-pinned-panel__actions">
          <button class="uah-pinned-panel__button uah-pinned-panel__button--resize" type="button">Unlock size</button>
          <button class="uah-pinned-panel__button uah-pinned-panel__button--active uah-pinned-panel__button--pin" type="button">Unpin</button>
          <button class="uah-pinned-panel__button uah-pinned-panel__button--close" type="button" aria-label="Close">X</button>
        </div>
      </div>
      <iframe title="UAH pinned panel" src="${Z()}"></iframe>
    `;const p=i.querySelector(".uah-pinned-panel__button--resize"),m=()=>{const o=!!e.uiState.panelResizeUnlocked;p?.classList.toggle("uah-pinned-panel__button--active",o),p&&(p.textContent=o?"Lock size":"Unlock size")};return p?.addEventListener("click",async()=>{const o=!e.uiState.panelResizeUnlocked;e.uiState.panelResizeUnlocked=o,o&&(e.uiState.panelSize=E({width:i.offsetWidth||b,height:i.offsetHeight||P},{viewportWidth:t.innerWidth,viewportHeight:t.innerHeight})),o||(e.uiState.panelSize=I({viewportWidth:t.innerWidth,viewportHeight:t.innerHeight})),g(i),m(),l(i,e.drag?.getPosition?.()||e.uiState.panelPosition),await x("setPinnedUiState",{panelResizeUnlocked:o}).catch(()=>null)}),i.querySelector(".uah-pinned-panel__button--pin")?.addEventListener("click",async()=>{await x("setPinnedUiState",{pinEnabled:!1}).catch(()=>null),_.hide()}),i.querySelector(".uah-pinned-panel__button--close")?.addEventListener("click",async()=>{await x("dismissPinnedPanel").catch(()=>null),_.hide()}),n.body.appendChild(i),m(),f(i),v(i),M(i),l(i,s),i}const _={show(i={}){J(n),e.uiState={...e.uiState,...i};const a=k();return d(a),l(a,e.uiState.panelPosition),a.style.display="block",{ok:!0}},hide(){return h(),r(),K(n),e.panelResizeObserver?.disconnect?.(),e.panelResizeObserver=null,e.resizeHandler&&(t.removeEventListener("resize",e.resizeHandler),e.resizeHandler=null),{ok:!0}}};return t.__UAH_PINNED_PANEL__=_,_}ee()})();
