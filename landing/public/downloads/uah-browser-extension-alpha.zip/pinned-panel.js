(function(){"use strict";const k=globalThis.browser,L=globalThis.chrome;function D(){return L?.runtime?.lastError?.message||""}function T(e,i,...t){return new Promise((r,u)=>{const a=e?.[i];if(typeof a!="function"){u(new Error(`Extension API method '${i}' is unavailable.`));return}try{a.call(e,...t,l=>{const f=D();if(f){u(new Error(f));return}r(l)})}catch(l){u(l)}})}function B(e,i,...t){const r=e?.[i];return typeof r!="function"?Promise.reject(new Error(`Extension API method '${i}' is unavailable.`)):Promise.resolve(r.call(e,...t))}function O(e,i,...t){return k?B(e(k),i,...t):L?T(e(L),i,...t):Promise.reject(new Error("Browser extension APIs are unavailable in this context."))}function F(e){return O(i=>i.runtime,"sendMessage",e)}async function y(e,i={}){const t=await F({type:e,payload:i});if(!t?.ok){const r=new Error(t?.message||"Extension request failed.");throw r.code=t?.code||"EXTENSION_REQUEST_FAILED",r.status=t?.status||null,r}return t.data}const E=16,_=196,x=380,N=196,$=320,A=720,C=Object.freeze({pinEnabled:!1,panelPosition:null,panelSize:null,panelResizeUnlocked:!1,debugPosition:null});function S(e){const i=Number(e);return Number.isFinite(i)?i:null}function q(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const i=S(e.top),t=S(e.left);return i===null||t===null?null:{top:Math.round(i),left:Math.round(t)}}function X(e){if(!e||typeof e!="object"||Array.isArray(e))return null;const i=S(e.width),t=S(e.height);return i===null||t===null?null:{width:Math.round(i),height:Math.round(t)}}function z({viewportWidth:e=1280,width:i=_,top:t=E,margin:r=E}={}){const u=Math.max(r,Math.round(e-i-r));return{top:Math.max(r,Math.round(t)),left:u}}function w(e,{viewportWidth:i=1280,viewportHeight:t=720,minWidth:r=N,minHeight:u=$,maxWidth:a=A,margin:l=E}={}){const f=X(e)||{width:_,height:x},d=Math.max(r,Math.min(a,Math.round(i-l*2))),h=Math.max(u,Math.round(t-l*2));return{width:Math.min(d,Math.max(r,f.width)),height:Math.min(h,Math.max(u,f.height))}}function U(e={}){return w({width:_,height:x},e)}function H(e,{viewportWidth:i=1280,viewportHeight:t=720,width:r=_,height:u=x,margin:a=E}={}){const l=q(e)||z({viewportWidth:i,width:r,margin:a}),f=Math.max(a,Math.round(i-r-a)),d=Math.max(a,Math.round(t-u-a));return{left:Math.min(f,Math.max(a,l.left)),top:Math.min(d,Math.max(a,l.top))}}function j(e,i){!e||!i||(e.style.left=`${i.left}px`,e.style.top=`${i.top}px`)}function M(e,i,t={}){return{viewportWidth:i.innerWidth||1280,viewportHeight:i.innerHeight||720,width:e?.offsetWidth||t.width||0,height:e?.offsetHeight||t.height||0}}function G({handle:e,target:i,initialPosition:t=null,defaultPosition:r=null,ignoreSelector:u='button, a, input, select, textarea, [role="button"]',fallbackSize:a={},onMove:l=null,onCommit:f=null,win:d=window}={}){if(!e||!i||!d?.addEventListener)return{getPosition:()=>null,setPosition(){},destroy(){}};let h=H(t||r||z(M(i,d,a)),M(i,d,a)),m=!1,P=0,n=0,o=h.left,s=h.top;function b(c,K=!0){h=H(c,M(i,d,a)),j(i,h),K&&typeof l=="function"&&l({...h})}function v(c){m&&(c.preventDefault(),b({left:o+(c.clientX-P),top:s+(c.clientY-n)}))}function g(){m&&(m=!1,d.removeEventListener("pointermove",v),d.removeEventListener("pointerup",g),typeof f=="function"&&f({...h}))}function R(c){c.button!==void 0&&c.button!==0||u&&c.target?.closest?.(u)||(m=!0,P=c.clientX,n=c.clientY,o=h.left,s=h.top,d.addEventListener("pointermove",v),d.addEventListener("pointerup",g))}return e.addEventListener("pointerdown",R),b(h,!1),{getPosition(){return{...h}},setPosition(c){b(c,!1)},destroy(){m=!1,e.removeEventListener("pointerdown",R),d.removeEventListener("pointermove",v),d.removeEventListener("pointerup",g)}}}const p="uah-pinned-panel-root",I="uah-pinned-panel-style";function Y(e=document){if(e.getElementById(I))return;const i=e.createElement("style");i.id=I,i.textContent=`
    #${p} {
      position: fixed;
      z-index: 2147483645;
      width: ${_}px;
      height: min(${x}px, calc(100vh - 32px));
      min-width: ${N}px;
      min-height: ${$}px;
      max-width: min(${A}px, calc(100vw - 32px));
      max-height: calc(100vh - 32px);
      border-radius: 18px;
      border: 1px solid rgba(191, 219, 254, 0.92);
      box-shadow: 0 24px 64px rgba(15, 23, 42, 0.28);
      overflow: hidden;
      background: rgba(248, 250, 252, 0.96);
      backdrop-filter: blur(16px);
      resize: none;
    }
    #${p}::after {
      content: "";
      position: absolute;
      right: 0;
      bottom: 0;
      width: 18px;
      height: 18px;
      background: rgba(248, 250, 252, 0.98);
      pointer-events: none;
    }
    #${p}.uah-pinned-panel--resize-unlocked {
      resize: both;
    }
    #${p}.uah-pinned-panel--resize-unlocked::after {
      display: none;
    }
    #${p} .uah-pinned-panel__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px 14px;
      background: linear-gradient(135deg, rgba(239, 246, 255, 0.98), rgba(255, 255, 255, 0.96));
      border-bottom: 1px solid rgba(226, 232, 240, 0.9);
      cursor: move;
      user-select: none;
    }
    #${p} .uah-pinned-panel__eyebrow {
      margin: 0 0 4px;
      color: #1d4ed8;
      font: 700 11px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }
    #${p} .uah-pinned-panel__title {
      margin: 0;
      color: #0f172a;
      font: 700 15px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    }
    #${p} .uah-pinned-panel__actions {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-shrink: 0;
    }
    #${p} .uah-pinned-panel__button {
      border: 1px solid rgba(191, 219, 254, 1);
      border-radius: 999px;
      background: white;
      color: #1d4ed8;
      padding: 7px 11px;
      font: 700 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      cursor: pointer;
    }
    #${p} .uah-pinned-panel__button--active {
      background: #1d4ed8;
      border-color: #1d4ed8;
      color: white;
    }
    #${p} iframe {
      display: block;
      width: 100%;
      height: calc(100% - 60px);
      border: 0;
      background: transparent;
    }
    #${p}.uah-pinned-panel--compact {
      border-radius: 16px;
    }
    #${p}.uah-pinned-panel--compact .uah-pinned-panel__header {
      flex-wrap: wrap;
      align-items: flex-start;
    }
    #${p}.uah-pinned-panel--compact .uah-pinned-panel__actions {
      width: 100%;
      justify-content: flex-end;
    }
  `,e.head.appendChild(i)}function W(e=document){return e.getElementById(p)}function Q(e=document){W(e)?.remove()}function V(){return`${globalThis.chrome?.runtime?.getURL?.("popup.html")||""}?surface=pinned`}function J(e=window,i=document){if(e.__UAH_PINNED_PANEL__)return e.__UAH_PINNED_PANEL__;const t={uiState:{...C},drag:null,resizeHandler:null,panelResizeObserver:null};function r(){t.drag?.destroy?.(),t.drag=null}function u(){const n={viewportWidth:e.innerWidth,viewportHeight:e.innerHeight};return t.uiState.panelResizeUnlocked?w(t.uiState.panelSize,n):U(n)}function a(n){const o=!!t.uiState.panelResizeUnlocked;n.classList.toggle("uah-pinned-panel--resize-unlocked",o)}function l(n,o){const s=u();n.style.width=`${s.width}px`,n.style.height=`${s.height}px`,n.classList.toggle("uah-pinned-panel--compact",s.width<340),a(n);const b=H(o||z({viewportWidth:e.innerWidth,width:_}),{viewportWidth:e.innerWidth,viewportHeight:e.innerHeight,width:s.width,height:s.height});t.drag?.setPosition(b)}function f(n){r();const o=n.querySelector(".uah-pinned-panel__header");t.drag=G({handle:o,target:n,initialPosition:t.uiState.panelPosition,defaultPosition:z({viewportWidth:e.innerWidth,width:_}),fallbackSize:{width:_,height:x},onCommit(s){t.uiState.panelPosition=s,y("setPinnedUiState",{panelPosition:s}).catch(()=>null)},win:e})}function d(n){t.resizeHandler||(t.resizeHandler=()=>{t.uiState.panelSize=w(t.uiState.panelSize,{viewportWidth:e.innerWidth,viewportHeight:e.innerHeight});const o=t.drag?.getPosition?.()||t.uiState.panelPosition;l(n,o)},e.addEventListener("resize",t.resizeHandler))}function h(n){t.panelResizeObserver||typeof globalThis.ResizeObserver!="function"||(t.panelResizeObserver=new ResizeObserver(()=>{const o=w({width:n.offsetWidth,height:n.offsetHeight},{viewportWidth:e.innerWidth,viewportHeight:e.innerHeight});if(n.style.width=`${o.width}px`,n.style.height=`${o.height}px`,n.classList.toggle("uah-pinned-panel--compact",o.width<340),t.uiState.panelSize?.width!==o.width||t.uiState.panelSize?.height!==o.height){t.uiState.panelSize=o;const s=t.drag?.getPosition?.()||t.uiState.panelPosition;l(n,s),y("setPinnedUiState",{panelSize:o}).catch(()=>null)}}),t.panelResizeObserver.observe(n))}function m(){let n=W(i);if(n)return n;const o=u(),s=H(t.uiState.panelPosition||z({viewportWidth:e.innerWidth,width:o.width}),{viewportWidth:e.innerWidth,viewportHeight:e.innerHeight,width:o.width,height:o.height});n=i.createElement("div"),n.id=p,n.style.width=`${o.width}px`,n.style.height=`${o.height}px`,n.style.left=`${s.left}px`,n.style.top=`${s.top}px`,n.style.display="none",n.classList.toggle("uah-pinned-panel--compact",o.width<340),n.innerHTML=`
      <div class="uah-pinned-panel__header">
        <div>
          <p class="uah-pinned-panel__eyebrow">UAH Browser Companion</p>
          <p class="uah-pinned-panel__title">Pinned applicant panel</p>
        </div>
        <div class="uah-pinned-panel__actions">
          <button class="uah-pinned-panel__button uah-pinned-panel__button--resize" type="button">Unlock size</button>
          <button class="uah-pinned-panel__button uah-pinned-panel__button--active uah-pinned-panel__button--pin" type="button">Unpin</button>
          <button class="uah-pinned-panel__button uah-pinned-panel__button--close" type="button" aria-label="Close">X</button>
        </div>
      </div>
      <iframe title="UAH pinned panel" src="${V()}"></iframe>
    `;const b=n.querySelector(".uah-pinned-panel__button--resize"),v=()=>{const g=!!t.uiState.panelResizeUnlocked;b?.classList.toggle("uah-pinned-panel__button--active",g),b&&(b.textContent=g?"Lock size":"Unlock size")};return b?.addEventListener("click",async()=>{const g=!t.uiState.panelResizeUnlocked;t.uiState.panelResizeUnlocked=g,g&&(t.uiState.panelSize=w({width:n.offsetWidth||_,height:n.offsetHeight||x},{viewportWidth:e.innerWidth,viewportHeight:e.innerHeight})),g||(t.uiState.panelSize=U({viewportWidth:e.innerWidth,viewportHeight:e.innerHeight})),a(n),v(),l(n,t.drag?.getPosition?.()||t.uiState.panelPosition),await y("setPinnedUiState",{panelResizeUnlocked:g}).catch(()=>null)}),n.querySelector(".uah-pinned-panel__button--pin")?.addEventListener("click",async()=>{await y("setPinnedUiState",{pinEnabled:!1}).catch(()=>null),P.hide()}),n.querySelector(".uah-pinned-panel__button--close")?.addEventListener("click",async()=>{await y("dismissPinnedPanel").catch(()=>null),P.hide()}),i.body.appendChild(n),v(),f(n),d(n),h(n),l(n,s),n}const P={show(n={}){Y(i),t.uiState={...t.uiState,...n};const o=m();return l(o,t.uiState.panelPosition),o.style.display="block",{ok:!0}},hide(){return r(),Q(i),t.panelResizeObserver?.disconnect?.(),t.panelResizeObserver=null,t.resizeHandler&&(e.removeEventListener("resize",t.resizeHandler),t.resizeHandler=null),{ok:!0}}};return e.__UAH_PINNED_PANEL__=P,P}J()})();
